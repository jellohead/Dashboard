import "../../src/geo/geo";
import "../../src/geo/clip-view";

d3.geo.clipView = d3_geo_clipView;
