var d3_format_decimalPoint = {decimal_point},
    d3_format_thousandsSeparator = {thousands_sep},
    d3_format_grouping = {grouping};
